function love.conf(t)
    t.window.width = 800
    t.window.height = 600
    t.window.title = "Collect The coins!"
    t.window.fullscreen = false
    t.window.resizable = false
    t.window.vsync = true
end
