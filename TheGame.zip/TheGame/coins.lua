local circles = {}

circles.circles = {}
local timer = 0
local spawnI = 4
local coin


function circles.update(dt)
    timer = timer + dt
    if timer >= spawnI then
        timer = timer - spawnI
        local newC = {
            x = math.random(800),
            y = math.random(600),
            r = 20,
        }
        table.insert(circles.circles, newC)  -- insert into circles.circles
        spawnI = math.random(1, 6)
    end
end

function circles.draw()
    
    for _, circle in ipairs(circles.circles) do
        love.graphics.circle("line", circle.x, circle.y, circle.r)  -- use circle.x and circle.y here
        love.graphics.draw(coin, circle.x - 20, circle.y - 20)
    end
end
function circles.load()
    coin = love.graphics.newImage("Images/Characters/Coin.png")
end

return circles
