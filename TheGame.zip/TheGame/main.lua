-- varaibles
x, y = 400, 300
radius = 50
score = 0
timer = 120
timerA = 0
gameState = 0
local music

local exT = 3
local exTA = 0

local player
local BG
local coin = require("coins")
local bigFont = love.graphics.newFont(40)  -- 30 pixels size#

local coinSFX


function love.draw()
    love.graphics.setFont(bigFont)
    love.graphics.draw(BG, 0, 0)
    love.graphics.setColor(1,1,1,0)
    love.graphics.rectangle("fill", x, y, 40, 40)
    love.graphics.setColor(1,1,1,1)
    love.graphics.draw(player, x - 20, y - 20)
    love.graphics.print("Score: " ..tostring(score), 400, 50)
    coin.draw()
    love.graphics.print("Timer: " ..tostring(timer), 0, 0)
    if gameState == 1 then
        love.graphics.print("Game over!", 400, 300)




    end

end

function love.update(dt)

    if gameState == 0 then
        Movement(150, dt)

        for i = #coin.circles, 1, -1 do
            local c = coin.circles[i]
            if checkRectCircleCollision(c.x, c.y, c.r, x, y, 40, 49) then
                coinSFX:play()
                score = score + 1
                table.remove(coin.circles, i) -- remove the circle after collecting it
            end
        end

        coin.update(dt)
        love.window.setTitle("C0llect the coins! Score: " .. tostring(score))

        timerI(dt)
    else
        if exT >= 0 then
            exTA = exTA + dt
            if exTA > 1 then
                exTA = exTA - 1
                exT = exT - 1
            end

            love.event.quit()
        end

        
    
    end

end

function Movement(speed, dt)
    if love.keyboard.isDown("right") then
        x = x + speed * dt
    end
    if love.keyboard.isDown("left") then
        x = x - speed * dt
    end
    if love.keyboard.isDown("up") then
        y = y - speed * dt
    end
    if love.keyboard.isDown("down") then
        y = y + speed * dt
    end
end

function checkRectCircleCollision(cx, cy, cr, rx, ry, rw, rh)
    -- Find the closest point to the circle within the rectangle
    local closestX = math.max(rx, math.min(cx, rx + rw))
    local closestY = math.max(ry, math.min(cy, ry + rh))

    -- Calculate the distance between the circle's center and this closest point
    local dx = cx - closestX
    local dy = cy - closestY

    -- If the distance is less than the circle's radius, there's a collision
    return (dx * dx + dy * dy) < (cr * cr)
end


function love.load()
    music = love.audio.newSource("Music/GameMusic.wav", "stream")
    music:setLooping(true)
    music:play()
    coinSFX = love.audio.newSource("Music/sounds/Coin.wav", "static")
    local icon = love.image.newImageData("Images/Icon.png")
    love.window.setIcon(icon)


    BG = love.graphics.newImage("Images/Background.png")
    player = love.graphics.newImage("Images/Characters/Player.png")
    coin.load()
end

function timerI(dt)
    if timer >= 0 then
        timerA = timerA + dt
        if timerA > 1 then
            timerA = timerA - 1
            timer = timer - 1
        end
    else
        gameState = 1
    end
end

